local keyboard = libs.keyboard;

-- actions.sublimetext = function()
-- 	keyboard.stroke ( "shift","ctrl","command","alt","s" );
-- end

actions.alttab = function()
	keyboard.stroke ( "alt","tab" );
end

actions.exit = function()
	keyboard.stroke ( "alt","f4" );
end

actions.navigateslides_down = function()
	keyboard.stroke ( "ctrl","command","alt","oem_plus" );
end

actions.navigateslides_up = function()
	keyboard.stroke ( "ctrl","command","alt","oem_minus" );
end

actions.navigatemedialinks_down = function()
	keyboard.stroke ( "ctrl","alt","oem_plus" );
end

actions.navigatemedialinks_up = function()
	keyboard.stroke ( "ctrl","alt","oem_minus" );
end

actions.zoom_in = function()
	keyboard.stroke ( "ctrl","shift","oem_plus" );
end

actions.zoom_out = function()
	keyboard.stroke ( "ctrl","shift","oem_minus" );
end

